package com.quiz;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.model.Quiz;

@WebServlet("/QuizServlet")
public class QuizServlet extends HttpServlet {
	public  int count=0;
	private int score=0;
 
	public void init() { 
		count = 0;
		score=0;
	} 
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("score", 0);
		request.setAttribute("sequence",Quiz.questions[0]);
		request.getRequestDispatcher("/index.jsp").forward(request, response);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NumberFormatException {
		String resul=request.getParameter("quiz");  
		response.setContentType("text/html");
		if(Integer.parseInt(resul)==Quiz.answers[count])
			score++;
	
		if(count<Quiz.answers.length-1) {
    			request.setAttribute("score", score);
				count++;
    	    	request.setAttribute("sequence",Quiz.nextQuestion(count));
			
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			//}
			}else {
					PrintWriter out = response.getWriter();
					out.print("<html><head><title>Test</title></head><body>");
					out.print("<h1>The Number Quiz</h1>");
					out.print("<p>The Current Score is :"+score+"</p>");
					out.print("<p>You have completed the Number Quiz, with a score of "+score+" out of "+Quiz.questions.length+"</p>");
						out.print("</body></html>");
					}
	}
}