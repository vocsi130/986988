package com.quiz.model;

public class Quiz {
public static String[] questions= {
"3, 1, 4, 1, 5",		
"1, 1, 2, 3, 5"	,	
"1, 4, 9, 16, 25",	
"2, 3, 5, 7, 11",	
"1, 2, 4, 8, 16"		
};

public static int[] answers= {9,8,36,13,32};

	public Quiz() {
	}
	
	
  public static String nextQuestion(int pos) {
	 return questions[pos];
  }
}
