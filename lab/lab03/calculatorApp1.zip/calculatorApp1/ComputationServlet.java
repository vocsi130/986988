package com.computation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.computation.model.Computation;
public class ComputationServlet   extends HttpServlet {

	   // Method to handle GET method request.
	   public void doGet(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {
	    
	   }

	   // Method to handle POST method request.
	   public void doPost(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException, NumberFormatException {
			String a=request.getParameter("val1");
			String b=request.getParameter("val2");
			
			String c=request.getParameter("val3");
			String d=request.getParameter("val4");
			
			
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			if(!a.isEmpty() && !b.isEmpty()) {
				int val1=Integer.parseInt(a);
				int val2=Integer.parseInt(b);
				Computation cpSum=new Computation(val1, val2);
				int  sum=cpSum.sum();
				out.println("<br>"+val1+" + "+val2+" = "+sum);
			}
			
			if(!c.isEmpty() && !d.isEmpty()) {
				int val3=Integer.parseInt(c);
				int val4=Integer.parseInt(d);
				Computation cpMulti=new Computation(val3, val4);
			int  multi=cpMulti.multiply();
			out.println("<br>"+val3+" * "+val4+" = "+multi);
			}
			
	   }
	}