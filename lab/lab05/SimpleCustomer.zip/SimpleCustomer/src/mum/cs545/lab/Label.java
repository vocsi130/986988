package mum.cs545.lab;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class Label extends SimpleTagSupport {
	String theColor;
	String words; // render custom tag 
	public void doTag() throws JspException, IOException {
		JspWriter out = getJspContext().getOut(); if (theColor != null) {
			out.write(String.format( "<span style='color:%s'>%s</span>", theColor,
					words)); } else { out.write(String.format("<span>%s</span>", words));
					}
	}
	//Need a setter for each attribute of custom tag 
	public void setTheColor(String theColor) { this.theColor = theColor;
	}

	public void setWords(String words) {
		this.words = words;
	}
}