package com.computation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.computation.model.Computation;

@WebServlet("/ComputationServlet")
public class ComputationServlet extends HttpServlet {

		public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NumberFormatException {
		String a = request.getParameter("val1");
		String b = request.getParameter("val2");

		String c = request.getParameter("val3");
		String d = request.getParameter("val4");

		response.setContentType("text/html");
		if (!a.isEmpty() && !b.isEmpty()) {
			int val1 = Integer.parseInt(a);
			int val2 = Integer.parseInt(b);
			Computation cpSum = new Computation(val1, val2);
			int sum = cpSum.sum();
			request.setAttribute("val1", val1);
			request.setAttribute("val2", val2);
			request.setAttribute("sum", sum);
		}

		if (!c.isEmpty() && !d.isEmpty()) {
			int val3 = Integer.parseInt(c);
			int val4 = Integer.parseInt(d);
			Computation cpMulti = new Computation(val3, val4);
			int multi = cpMulti.multiply();
			request.setAttribute("val3", val3);
			request.setAttribute("val4", val4);
			request.setAttribute("multi", multi);
		}
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	}
}