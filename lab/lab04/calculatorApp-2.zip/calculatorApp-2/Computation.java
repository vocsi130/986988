package com.computation.model;

public class Computation {
private int a;
private int b;

	public Computation(int a, int b) {
	this.a=a;
	this.b=b;
	}
	
	public int sum() {
		return a+b;
	}
	
	public int multiply() {
	
		return a*b;
	}
}
